package com.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase {
	
	//Page factory object repository
	@FindBy(xpath="//input[@placeholder='E-mail address']")
	WebElement username;
	@FindBy(xpath="//input[@placeholder='Password']")
	WebElement passwrd;
	@FindBy(xpath="//div[@class='ui fluid large blue submit button']")
	WebElement loginbtn;
	@FindBy(xpath="//a[contains(text(),'Sign Up')]")
	WebElement signupbtn;
	
	//Initializing the page objects
	public LoginPage() {
	
		PageFactory.initElements(driver, this);
		
	}
	
	//Actions
	public String validateLoginPageTitle()
	{
		String title=driver.getTitle();
		return title;
	}
	
	public HomePage login(String uname,String pword) throws Exception
	{
		//System.out.println("login home");
		/*wait.until(ExpectedConditions.visibilityOf(username)).sendKeys(uname);
		wait.until(ExpectedConditions.visibilityOf(passwrd)).sendKeys(pword);*/
		username.sendKeys(uname);
		Thread.sleep(2000);
		passwrd.sendKeys(pword);
		Thread.sleep(2000);
		loginbtn.click();
		return new HomePage();
	}
	
	

}
